Autor Marcel Wątruch 2A
Data 11.11.2023
Przedmiot na który jest ściąga Historia



Aby ponownie sprawdzić czy program działa 
trzeba wcisnąć wycofaj



Dołączone zostały dwa pliki skryptu .py oraz 
.exe .py jest tylko po to by zobaczyć jak 
działa program



W folderze rezultat znajdują się pliki/foldery 
które powinny pojawić się PO uruchomieniu 
skryptu/programu. Nie są one wynikiem działania
bezpośrednio programu tylko to co powinno się
pojawić.

